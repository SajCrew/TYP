using Ast.Statements;
using Semantics.Exceptions;

namespace Semantics.Symbols;

/// <summary>Names declared in the current lexical scope, with parent fallback.</summary>
public sealed class SymbolsTable
{
    private readonly Dictionary<string, DeclarationStatement> _local = new();

    public SymbolsTable(SymbolsTable? parent)
    {
        Parent = parent;
    }

    public SymbolsTable? Parent { get; }

    public DeclarationStatement GetSymbol(string name)
    {
        for (SymbolsTable? scope = this; scope is not null; scope = scope.Parent)
        {
            if (scope._local.TryGetValue(name, out DeclarationStatement? found))
            {
                return found;
            }
        }

        throw new UnknownSymbolException(name);
    }

    public void DefineSymbol(string name, DeclarationStatement symbol)
    {
        if (!_local.TryAdd(name, symbol))
        {
            throw DuplicateSymbolException.DuplicateVariableOrFunction(name);
        }
    }
}
