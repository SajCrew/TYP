using System.Text;
using Ast.Statements;
using CompilerParser;
using MsilBackend;
using MsilCodegen;
using Semantics;

namespace Compiler;

public class CompilerDriver
{
    public void Compile(string inputPath, string outputPath)
    {
        string source = File.ReadAllText(inputPath, Encoding.UTF8);
        BlockStatement tree = BuildSyntaxTree(source);
        Validate(tree);
        EmitExecutable(tree, outputPath);
    }

    private static BlockStatement BuildSyntaxTree(string source)
    {
        return new Parser(source).ParseProgram();
    }

    private static void Validate(BlockStatement tree)
    {
        new SemanticsChecker().Check(tree);
    }

    private static void EmitExecutable(BlockStatement tree, string destination)
    {
        ExecutableBuilder output = new(destination);
        MsilCodegenPass generator = new(output.ModuleBuilder);
        var entryPoint = generator.GenerateProgramCode(tree);
        output.Save(entryPoint);
    }
}
