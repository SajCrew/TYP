using Ast.Types;
using ValueType = Runtime.ValueType;

namespace MsilCodegen;

/// <summary>Resolves Pascal++ value types to runtime reflection types.</summary>
public class TypeMapper
{
    private readonly Dictionary<(ValueType Type, bool IsArray), Type> _cache = new();

    public Type MapType(ValueType type) => Resolve(type, false);

    public Type MapArrayType(ValueType elementType) => Resolve(elementType, true);

    public Type MapTypeNode(TypeNode node) => node switch
    {
        ScalarTypeNode scalar => MapType(scalar.Type),
        ArrayTypeNode array => MapArrayType(array.ElementType),
        _ => throw new NotSupportedException($"Type {node} is not supported")
    };

    private Type Resolve(ValueType type, bool array)
    {
        var key = (type, array);
        if (_cache.TryGetValue(key, out var cached))
            return cached;

        Type scalarType = type switch
        {
            ValueType.Void => typeof(void),
            ValueType.Integer => typeof(int),
            ValueType.Float => typeof(double),
            ValueType.String => typeof(string),
            _ => throw new NotSupportedException($"Type of Pascal++ - {type} - can't convert in .NET")
        };
        Type resolved = array ? scalarType.MakeArrayType() : scalarType;
        _cache[key] = resolved;
        return resolved;
    }
}
