﻿using Ast.Statements;

namespace Ast.Declaration;

/// <summary>
/// Абстрактный класс с информацией о переменной или формальном параметре функции.
/// </summary>
public abstract class AbstractVariableDeclaration : DeclarationStatement
{
    protected AbstractVariableDeclaration(string name)
    {
        Name = name;
    }

    public string Name { get; }
}