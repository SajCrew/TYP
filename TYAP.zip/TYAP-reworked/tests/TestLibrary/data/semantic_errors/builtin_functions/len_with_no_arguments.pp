begin
    write(len());
end
