using System.Reflection;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Runtime.InteropServices;

namespace MsilBackend;

/// <summary>
/// Собирает исполняемый модуль для платформы .NET и сохраняет его в файл.
/// </summary>
public class ExecutableBuilder
{
    private readonly string _executablePath;
    private readonly string _runtimeConfigPath;
    private readonly PersistedAssemblyBuilder _assemblyBuilder;
    private readonly ModuleBuilder _moduleBuilder;

    public ExecutableBuilder(string executablePath)
    {
        _executablePath = executablePath;
        _runtimeConfigPath = Path.ChangeExtension(executablePath, "runtimeconfig.json");
        AssemblyName assemblyName = new(Path.GetFileNameWithoutExtension(executablePath));

        _assemblyBuilder = new PersistedAssemblyBuilder(
            assemblyName,
            coreAssembly: typeof(object).Assembly,
            assemblyAttributes:
            null
        );

        _moduleBuilder = _assemblyBuilder.DefineDynamicModule(Path.GetFileName(executablePath));
    }

    public ModuleBuilder ModuleBuilder => _moduleBuilder;

    public void Save(MethodBuilder mainMethod)
    {
        MetadataBuilder metadataBuilder = _assemblyBuilder.GenerateMetadata(
            out BlobBuilder ilStream,
            out BlobBuilder fieldData
        );

        MethodDefinitionHandle mainHandle = GetMethodDefinitionHandle(mainMethod);

        ManagedPEBuilder peBuilder = new(
            header: PEHeaderBuilder.CreateExecutableHeader(),
            metadataRootBuilder: new MetadataRootBuilder(metadataBuilder),
            ilStream: ilStream,
            mappedFieldData: fieldData,
            entryPoint: mainHandle
        );

        CreateExecutableFile(_executablePath, peBuilder);
        SetExecutePermissions(_executablePath);

        RuntimeConfigGenerator.SaveRuntimeConfig(_runtimeConfigPath);
    }

    private static void CreateExecutableFile(
        string executablePath,
        ManagedPEBuilder peBuilder
    )
    {
        var image = new BlobBuilder();
        peBuilder.Serialize(image);

        using var destination = File.Create(executablePath);
        image.WriteContentTo(destination);
    }

    /// <summary>
    /// Получает объект, необходимый для установки метода Main() как точки входа исполняемого файла.
    /// </summary>
    private static MethodDefinitionHandle GetMethodDefinitionHandle(MethodBuilder mainMethod)
    {
        // Получаем токен метода Main().
        const int rowMask = 0x00FFFFFF;
        return MetadataTokens.MethodDefinitionHandle(mainMethod.MetadataToken & rowMask);
    }

    /// <summary>
    /// Устанавливает UNIX-права на выполнение программы.
    /// </summary>
    private static void SetExecutePermissions(string executablePath)
    {
        if (OperatingSystem.IsWindows())
            return;

        File.SetUnixFileMode(
                executablePath,
                UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute |
                UnixFileMode.GroupRead | UnixFileMode.GroupExecute |
                UnixFileMode.OtherRead | UnixFileMode.OtherExecute
            );
    }
}