﻿using Ast.Declaration;
using Ast.Expressions;
using Ast.Statements;

namespace Ast;

public interface IAstVisitor
{
    void Visit(BinaryOperationExpression e);

    void Visit(UnaryOperationExpression e);

    void Visit(LiteralExpression e);

    void Visit(FunctionCallExpression s);

    void Visit(AssignmentStatement s);

    void Visit(IfElseStatement s);

    void Visit(ForLoopStatement s);

    void Visit(InputStatement s);

    void Visit(OutputStatement s);

    void Visit(BlockStatement s);

    void Visit(ReturnStatement s);

    void Visit(VariableDeclaration s);

    void Visit(FunctionDeclaration s);

    void Visit(WhileLoopStatement s);

    void Visit(BreakStatement s);

    void Visit(ContinueStatement s);

    void Visit(FunctionCallStatement s);

    void Visit(ParameterDeclaration parameterDeclarationStatement);

    void Visit(VariableExpression variableExpression);

    void Visit(IteratorDeclaration iteratorDeclarationStatement);

    void Visit(ArrayAccessExpression arrayAccessExpression);

    void Visit(ArrayLiteralExpression arrayLiteralExpression);
}