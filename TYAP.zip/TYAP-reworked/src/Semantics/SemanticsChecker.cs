using Ast;
using Ast.Statements;
using Semantics.Passes;
using Semantics.Symbols;

namespace Semantics;

public class SemanticsChecker
{
    private readonly IReadOnlyList<AbstractPass> _pipeline;

    public SemanticsChecker()
    {
        var rootScope = CreateRootScope();
        _pipeline = new AbstractPass[]
        {
            new ResolveNamesPass(rootScope),
            new CheckContextSensitiveRulesPass(),
            new ResolveTypesPass(),
        };
    }

    private static SymbolsTable CreateRootScope()
    {
        SymbolsTable result = new(null);
        HashSet<string> registered = new();
        foreach (var builtin in Builtins.Functions)
        {
            if (registered.Add(builtin.Name))
            {
                result.DefineSymbol(builtin.Name, builtin);
            }
        }
        return result;
    }

    public void Check(BlockStatement program)
    {
        for (int stage = 0; stage < _pipeline.Count; stage++)
        {
            program.Accept(_pipeline[stage]);
        }
    }
}
