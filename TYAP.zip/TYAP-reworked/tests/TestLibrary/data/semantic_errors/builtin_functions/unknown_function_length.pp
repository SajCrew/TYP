﻿begin
    length("test");
end