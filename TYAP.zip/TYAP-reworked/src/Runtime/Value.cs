using System.Globalization;

namespace Runtime;

public class Value : IEquatable<Value>
{
    public static readonly Value Void = new(VoidType.Value);

    private readonly object _value;

    public Value(string value) : this((object)value) { }
    public Value(double value) : this((object)value) { }
    public Value(int value) : this((object)value) { }
    private Value(VoidType value) : this((object)value) { }

    private Value(object value)
    {
        _value = value;
    }

    public ValueType GetValueType() => _value switch
    {
        int => ValueType.Integer,
        double => ValueType.Float,
        string => ValueType.String,
        VoidType => ValueType.Void,
        _ => throw new InvalidOperationException($"Unexpected value type: {_value.GetType()}"),
    };

    private T Unwrap<T>()
    {
        if (_value is T result)
        {
            return result;
        }

        throw new InvalidOperationException($"Expected {typeof(T).Name}, got {GetValueType()}");
    }

    public string AsString() => Unwrap<string>();
    public double AsFloat() => Unwrap<double>();
    public int AsInteger() => Unwrap<int>();

    public override string ToString() => _value switch
    {
        string text => text,
        int integer => integer.ToString(CultureInfo.InvariantCulture),
        double real => real.ToString(CultureInfo.InvariantCulture),
        VoidType => "void",
        _ => throw new InvalidOperationException($"Unexpected value type: {_value.GetType()}"),
    };

    public bool Equals(Value? other)
    {
        if (ReferenceEquals(this, other))
        {
            return true;
        }

        if (other is null || GetValueType() != other.GetValueType())
        {
            return false;
        }

        return (_value, other._value) switch
        {
            (string a, string b) => a == b,
            (double a, double b) => Numbers.AreEqual(a, b),
            (int a, int b) => Numbers.AreEqual(a, b),
            (VoidType, VoidType) => true,
            _ => throw new InvalidOperationException("Cannot compare the supplied values"),
        };
    }

    public override bool Equals(object? obj) => obj is Value other && Equals(other);

    public override int GetHashCode() => _value.GetHashCode();
}
