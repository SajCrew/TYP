using Ast.Declaration;
using Ast.Expressions;
using Ast.Statements;
using Semantics.Exceptions;

namespace Semantics.Passes;

public sealed class CheckContextSensitiveRulesPass : AbstractPass
{
    private int _functionDepth;
    private bool _currentScopeIsLoop;
    private readonly Stack<bool> _scopeHistory = new();

    public override void Visit(FunctionCallExpression expression)
    {
        base.Visit(expression);
        int expected = expression.Function.Parameters.Count;
        int actual = expression.Arguments.Count;
        if (actual != expected)
            throw new InvalidFunctionCallException(
                $"Function '{expression.Name}' expects {expected} arguments, but got {actual}");
    }

    public override void Visit(FunctionCallStatement statement) => statement.Expression.Accept(this);

    public override void Visit(ReturnStatement statement)
    {
        if (_functionDepth == 0)
            throw new InvalidExpressionException("'return' cannot be outside the function block.");
        base.Visit(statement);
    }

    public override void Visit(FunctionDeclaration declaration)
    {
        EnterScope(false);
        _functionDepth++;
        try { base.Visit(declaration); }
        finally
        {
            _functionDepth--;
            LeaveScope();
        }
    }

    public override void Visit(WhileLoopStatement statement)
    {
        EnterScope(true);
        try { base.Visit(statement); }
        finally { LeaveScope(); }
    }

    public override void Visit(ForLoopStatement statement)
    {
        EnterScope(true);
        try { base.Visit(statement); }
        finally { LeaveScope(); }
    }

    public override void Visit(BreakStatement statement)
    {
        base.Visit(statement);
        if (!_currentScopeIsLoop)
            throw new InvalidExpressionException("The \"breakout\" expression is allowed only inside the loop");
    }

    public override void Visit(ContinueStatement statement)
    {
        base.Visit(statement);
        if (!_currentScopeIsLoop)
            throw new InvalidExpressionException("The \"contra\" expression is allowed only inside the loop");
    }

    private void EnterScope(bool isLoop)
    {
        _scopeHistory.Push(_currentScopeIsLoop);
        _currentScopeIsLoop = isLoop;
    }

    private void LeaveScope()
    {
        _currentScopeIsLoop = _scopeHistory.Pop();
    }
}
