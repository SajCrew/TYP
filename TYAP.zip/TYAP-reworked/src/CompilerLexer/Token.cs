namespace CompilerLexer;

public class Token
{
    public Token(TokenType type) : this(type, new TokenValue(string.Empty))
    {
    }

    public Token(TokenType type, TokenValue value)
    {
        (Type, Value) = (type, value);
    }

    public TokenType Type { get; }
    public TokenValue Value { get; }

    public override bool Equals(object? obj) =>
        obj is Token token && token.Type == Type && Value.Equals(token.Value);

    public override int GetHashCode() => HashCode.Combine(Type, Value);
}
