namespace CompilerLexer;

public sealed class TextScanner : IScanner
{
    private readonly string _text;
    private int _position;

    public TextScanner(string str)
    {
        _text = str;
    }

    public bool IsEnd() => _position >= _text.Length;

    public char Peek(int n = 0)
    {
        int target = _position + n;
        return target < 0 || target >= _text.Length ? '\0' : _text[target];
    }

    public void Advance()
    {
        ++_position;
    }
}
