using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;

using Ast;
using Ast.Declaration;
using Ast.Expressions;
using Ast.Statements;
using Ast.Types;

using ValueType = Runtime.ValueType;

namespace MsilCodegen;

public class MsilCodegenPass : IAstVisitor
{
    private readonly ModuleBuilder _moduleBuilder;
    private readonly TypeMapper _typeMapper;
    private readonly BuiltinFunctionEmitter _builtinFunctionEmitter;

    /// <summary>
    /// Тип Program будущей программы.
    /// </summary>
    private TypeBuilder _programTypeBuilder = null!;

    /// <summary>
    /// Генератор инструкций для текущего метода.
    /// </summary>
    private ILGenerator _il = null!;

    /// <summary>
    /// Стек областей видимости переменных.
    /// </summary>
    private readonly Stack<Dictionary<string, LocalBuilder>> _scopesStack;

    /// <summary>
    /// Стек меток конца цикла для прерывания цикла (break).
    /// </summary>
    private readonly Stack<Label> _loopBreaksStack;

    /// <summary>
    /// Стек меток цикла для продолжения цикла (continue).
    /// </summary>
    private readonly Stack<Label> _loopContinuesStack;

    /// <summary>
    /// Словарь методов, соответствующих пользовательским функциям исходной программы.
    /// </summary>
    private readonly Dictionary<string, MethodBuilder> _userFunctionMethodsMap;

    public MsilCodegenPass(ModuleBuilder moduleBuilder)
    {
        _moduleBuilder = moduleBuilder;
        _typeMapper = new TypeMapper();
        _builtinFunctionEmitter = new BuiltinFunctionEmitter();
        _scopesStack = new Stack<Dictionary<string, LocalBuilder>>();
        _loopBreaksStack = new Stack<Label>();
        _loopContinuesStack = new Stack<Label>();
        _userFunctionMethodsMap = new Dictionary<string, MethodBuilder>();
    }

    /// <summary>
    /// Текущая область видимости переменных.
    /// </summary>
    private Dictionary<string, LocalBuilder> CurrentScope => _scopesStack.Peek();

    public MethodBuilder GenerateProgramCode(BlockStatement program)
    {
        _programTypeBuilder = _moduleBuilder.DefineType(
            "Program",
            TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Class
        );

        MethodBuilder mainMethod = DefineProgramClassMethod("Main", typeof(void), Type.EmptyTypes);
        _il = mainMethod.GetILGenerator();

        // Устанавливаем кодировку UTF-8 для консоли
        MethodInfo utf8Encoding = typeof(Encoding).GetProperty("UTF8")!.GetMethod!;
        MethodInfo outputEncodingSetter = typeof(Console).GetProperty("OutputEncoding")!.SetMethod!;
        _il.Emit(OpCodes.Call, utf8Encoding);
        _il.Emit(OpCodes.Call, outputEncodingSetter);

        BeginScope();
        try
        {
            program.Accept(this);
            _il.Emit(OpCodes.Ret);
        }
        finally
        {
            EndScope();
        }

        _programTypeBuilder.CreateType();

        return mainMethod;
    }

    public void Visit(BinaryOperationExpression e)
    {
        if (e.Left.ResultType == ValueType.String && e.Right.ResultType == ValueType.String)
        {
            EmitStringsBinaryOperation(e);
        }
        else
        {
            EmitIntegersOrFloatBinaryOperation(e);
        }
    }

    public void Visit(UnaryOperationExpression e)
    {
        e.Operand.Accept(this);

        switch (e.Operation)
        {
            case UnaryOperation.Minus:
                if (e.ResultType != ValueType.Integer && e.ResultType != ValueType.Float)
                {
                    throw new InvalidOperationException(
                        $"Unary minus expect number, but got {e.ResultType}");
                }

                _il.Emit(OpCodes.Neg);
                break;

            case UnaryOperation.Not:
                EmitLogicalNot();
                break;

            default:
                throw new NotSupportedException();
        }
    }

    public void Visit(LiteralExpression e)
    {
        if (e.ResultType == ValueType.Integer)
        {
            _il.Emit(OpCodes.Ldc_I4, e.Value.AsInteger());
        }
        else if (e.ResultType == ValueType.String)
        {
            _il.Emit(OpCodes.Ldstr, e.Value.AsString());
        }
        else if (e.ResultType == ValueType.Float)
        {
            _il.Emit(OpCodes.Ldc_R8, e.Value.AsFloat());
        }
        else
        {
            throw new InvalidOperationException($"Literal of type '{e.ResultType}' is not supported");
        }
    }

    public void Visit(AssignmentStatement s)
    {
        switch (s.Target)
        {
            case VariableExpression variableTarget:
                s.Value.Accept(this);
                LocalBuilder local = FindVariable(variableTarget.Name);
                _il.Emit(OpCodes.Stloc, local);
                break;

            case ArrayAccessExpression arrayAccess:
                EmitArrayElementStore(arrayAccess, () => s.Value.Accept(this));
                break;

            default:
                throw new InvalidOperationException(
                    $"Assignment to {s.Target.GetType().Name} is not supported"
                );
        }
    }

    public void Visit(InputStatement s)
    {
        switch (s.Target)
        {
            case VariableExpression variableTarget:
                EmitReadIntoLocal(FindVariable(variableTarget.Name));
                break;

            case ArrayAccessExpression arrayAccess:
                EmitArrayElementStore(arrayAccess, () => EmitReadScalar(arrayAccess.ResultType));
                break;

            default:
                throw new InvalidOperationException(
                    $"read() target {s.Target.GetType().Name} is not supported"
                );
        }
    }

    public void Visit(ArrayAccessExpression e)
    {
        EmitArrayElementLoad(e);
    }

    public void Visit(ArrayLiteralExpression e)
    {
        ValueType elementType = e.InferredArrayType.ElementType;
        Type ilElementType = _typeMapper.MapType(elementType);

        _il.Emit(OpCodes.Ldc_I4, e.Elements.Count);
        _il.Emit(OpCodes.Newarr, ilElementType);

        for (int i = 0; i < e.Elements.Count; i++)
        {
            _il.Emit(OpCodes.Dup);
            _il.Emit(OpCodes.Ldc_I4, i);
            e.Elements[i].Accept(this);
            _il.Emit(OpCodes.Stelem, ilElementType);
        }
    }

    public void Visit(OutputStatement s)
    {
        foreach (Expression argument in s.Arguments)
        {
            argument.Accept(this);

            if (argument.ResultType == ValueType.Float)
            {
                WriteFloat();
            }
            else
            {
                Type argType = argument.ResultType switch
                {
                    ValueType.Integer => typeof(int),
                    ValueType.String => typeof(string),
                    _ => throw new InvalidOperationException($"Output type '{argument.ResultType}' is not supported"),
                };

                MethodInfo writeMethod = GetMethod(typeof(Console), "Write", [argType]);
                _il.Emit(OpCodes.Call, writeMethod);
            }
        }

        MethodInfo writelnMethod = GetMethod(typeof(Console), "WriteLine", Type.EmptyTypes);
        _il.Emit(OpCodes.Call, writelnMethod);
    }

    public void Visit(BlockStatement s)
    {
        if (s.IsNewScope)
        {
            BeginScope();
            try
            {
                foreach (Statement statement in s.Statements)
                {
                    statement.Accept(this);
                }
            }
            finally
            {
                EndScope();
            }
        }
        else
        {
            foreach (Statement statement in s.Statements)
            {
                statement.Accept(this);
            }
        }
    }

    public void Visit(VariableDeclaration s)
    {
        if (s.DeclaredType is ArrayTypeNode arrayType)
        {
            EmitDeclareArrayVariable(s.Name, arrayType, s.Value);
            return;
        }

        Type ilType = _typeMapper.MapTypeNode(s.DeclaredType);
        LocalBuilder local = _il.DeclareLocal(ilType);
        CurrentScope[s.Name] = local;

        if (s.Value != null)
        {
            s.Value.Accept(this);
            _il.Emit(OpCodes.Stloc, local);
            return;
        }

        EmitDefaultScalarValue(((ScalarTypeNode)s.DeclaredType).Type);
        _il.Emit(OpCodes.Stloc, local);
    }

    public void Visit(VariableExpression e)
    {
        LocalBuilder local = FindVariable(e.Name);
        _il.Emit(OpCodes.Ldloc, local);
    }

    public void Visit(FunctionCallExpression s)
    {
        foreach (Expression argument in s.Arguments)
        {
            argument.Accept(this);
        }

        if (s.Function is BuiltInFunctionDeclaration)
        {
            _builtinFunctionEmitter.EmitCallBuiltinFunction(s.Name, _il);
        }
        else
        {
            if (!_userFunctionMethodsMap.TryGetValue(s.Name, out MethodBuilder? method))
            {
                throw new InvalidOperationException($"Cannot find method of .NET for function with name {s.Name}");
            }

            _il.Emit(OpCodes.Call, method);
        }
    }

    public void Visit(IfElseStatement s)
    {
        Label endLabel = _il.DefineLabel();
        if (s.ElseBranch != null)
        {
            Label elseLabel = _il.DefineLabel();
            s.Condition.Accept(this);
            _il.Emit(OpCodes.Brfalse, elseLabel);

            s.ThenBranch.Accept(this);
            _il.Emit(OpCodes.Br, endLabel);

            _il.MarkLabel(elseLabel);
            s.ElseBranch.Accept(this);
        }
        else
        {
            s.Condition.Accept(this);
            _il.Emit(OpCodes.Brfalse, endLabel);
            s.ThenBranch.Accept(this);
        }

        _il.MarkLabel(endLabel);
    }

    public void Visit(WhileLoopStatement e)
    {
        Label loopStart = _il.DefineLabel();
        Label loopEnd = _il.DefineLabel();

        _loopBreaksStack.Push(loopEnd);
        _loopContinuesStack.Push(loopStart);

        _il.MarkLabel(loopStart);
        e.Condition.Accept(this);
        _il.Emit(OpCodes.Brfalse, loopEnd);

        e.Body.Accept(this);
        _il.Emit(OpCodes.Br, loopStart);

        _il.MarkLabel(loopEnd);

        _loopBreaksStack.Pop();
        _loopContinuesStack.Pop();
    }

    public void Visit(ForLoopStatement e)
    {
        Label loopStart = _il.DefineLabel();
        Label loopEnd = _il.DefineLabel();
        Label loopIncrement = _il.DefineLabel();

        _loopBreaksStack.Push(loopEnd);
        _loopContinuesStack.Push(loopIncrement);

        BeginScope();

        ValueType iteratorType = e.Iterator.StartValue.ResultType;
        Type ilIteratorType = _typeMapper.MapType(iteratorType);
        LocalBuilder iterator = _il.DeclareLocal(ilIteratorType);
        CurrentScope[e.Iterator.Name] = iterator;

        e.Iterator.StartValue.Accept(this);
        _il.Emit(OpCodes.Stloc, iterator);

        _il.MarkLabel(loopStart);
        _il.Emit(OpCodes.Ldloc, iterator);
        e.EndValue.Accept(this);
        EmitConvertToCommonType(iteratorType, e.EndValue.ResultType);
        _il.Emit(OpCodes.Cgt);
        _il.Emit(OpCodes.Brtrue, loopEnd);

        e.Body.Accept(this);

        _il.MarkLabel(loopIncrement);
        _il.Emit(OpCodes.Ldloc, iterator);
        if (iteratorType == ValueType.Float)
        {
            _il.Emit(OpCodes.Ldc_R8, 1.0);
        }
        else
        {
            _il.Emit(OpCodes.Ldc_I4_1);
        }

        _il.Emit(OpCodes.Add);
        _il.Emit(OpCodes.Stloc, iterator);

        _il.Emit(OpCodes.Br, loopStart);

        _il.MarkLabel(loopEnd);

        _loopBreaksStack.Pop();
        _loopContinuesStack.Pop();
        EndScope();
    }

    public void Visit(IteratorDeclaration d)
    {
    }

    public void Visit(ReturnStatement s)
    {
        s.Value?.Accept(this);

        _il.Emit(OpCodes.Ret);
    }

    public void Visit(BreakStatement e)
    {
        Label loopEnd = _loopBreaksStack.Peek();
        _il.Emit(OpCodes.Br, loopEnd);
    }

    public void Visit(ContinueStatement e)
    {
        Label continueLabel = _loopContinuesStack.Peek();
        _il.Emit(OpCodes.Br, continueLabel);
    }

    public void Visit(FunctionDeclaration s)
    {
        MethodBuilder method = DefineProgramClassMethod(
            GetUserFunctionMethodName(s.Name),
            _typeMapper.MapType(s.ReturnType),
            s.Parameters.Select(p => _typeMapper.MapTypeNode(p.ResultType)).ToArray()
        );
        _userFunctionMethodsMap[s.Name] = method;

        ILGenerator previousIl = _il;

        try
        {
            _il = method.GetILGenerator();
            BeginScope();

            for (int i = 0, iEnd = s.Parameters.Count; i < iEnd; ++i)
            {
                AbstractParameterDeclaration param = s.Parameters[i];
                EmitDefineParameter(param.Name, param.ResultType, i);
            }

            s.Body.Accept(this);

            _il.Emit(OpCodes.Ret);
        }
        finally
        {
            EndScope();
            _il = previousIl;
        }
    }

    public void Visit(FunctionCallStatement s)
    {
        s.Expression.Accept(this);

        if (s.Expression.ResultType != ValueType.Void)
        {
            _il.Emit(OpCodes.Pop);
        }
    }

    public void Visit(ParameterDeclaration parameterDeclarationStatementStatement)
    {
    }

    /// <summary>
    /// Генерирует код возведения в степень.
    /// </summary>
    private void EmitPowerOperation(BinaryOperationExpression e)
    {
        MethodInfo mathPow = typeof(Math).GetMethod(
            "Pow",
            [typeof(double), typeof(double)]
        )!;

        e.Left.Accept(this);

        if (e.Left.ResultType == ValueType.Integer)
        {
            _il.Emit(OpCodes.Conv_R8);
        }

        e.Right.Accept(this);

        if (e.Right.ResultType == ValueType.Integer)
        {
            _il.Emit(OpCodes.Conv_R8);
        }

        _il.Emit(OpCodes.Call, mathPow);

        if (e.ResultType == ValueType.Integer)
        {
            _il.Emit(OpCodes.Conv_I4);
        }
    }

    /// <summary>
    /// Генерирует код вычисления бинарной операции над целыми и вещественными числами.
    /// </summary>
    private void EmitIntegersOrFloatBinaryOperation(BinaryOperationExpression expression)
    {
        // Операции с ленивым вычислением обрабатываем до вычисления операндов.
        if (expression.Operation == BinaryOperation.Exponentiate)
        {
            EmitPowerOperation(expression);
            return;
        }
        if (expression.Operation == BinaryOperation.And)
        {
            EmitLogicalAnd(expression);
            return;
        }
        if (expression.Operation == BinaryOperation.Or)
        {
            EmitLogicalOr(expression);
            return;
        }

        expression.Left.Accept(this);
        expression.Right.Accept(this);

        OpCode instruction = expression.Operation switch
        {
            BinaryOperation.Add => OpCodes.Add,
            BinaryOperation.Subtract => OpCodes.Sub,
            BinaryOperation.Multiply => OpCodes.Mul,
            BinaryOperation.Divide => OpCodes.Div,
            BinaryOperation.Modulo => OpCodes.Rem,
            BinaryOperation.Equal or BinaryOperation.NotEqual => OpCodes.Ceq,
            BinaryOperation.LessThan or BinaryOperation.GreaterThanOrEqual => OpCodes.Clt,
            BinaryOperation.GreaterThan or BinaryOperation.LessThanOrEqual => OpCodes.Cgt,
            _ => throw new NotSupportedException(
                $"Cannot generate MSIL for binary operation {expression.Operation}.")
        };
        _il.Emit(instruction);

        // Инверсия результата сравнения преобразует строгие отношения в нестрогие.
        if (expression.Operation is BinaryOperation.NotEqual or
            BinaryOperation.LessThanOrEqual or BinaryOperation.GreaterThanOrEqual)
        {
            EmitLogicalNot();
        }
    }

    /// <summary>
    /// Генерирует код логического "и" с вычислением по короткой схеме.
    /// </summary>
    private void EmitLogicalAnd(BinaryOperationExpression e)
    {
        Label falseLabel = _il.DefineLabel();
        Label endLabel = _il.DefineLabel();

        e.Left.Accept(this);
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Ceq);
        _il.Emit(OpCodes.Brtrue, falseLabel);

        e.Right.Accept(this);
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Ceq);
        _il.Emit(OpCodes.Brtrue, falseLabel);

        _il.Emit(OpCodes.Ldc_I4_1);
        _il.Emit(OpCodes.Br, endLabel);

        _il.MarkLabel(falseLabel);
        _il.Emit(OpCodes.Ldc_I4_0);

        _il.MarkLabel(endLabel);
    }

    /// <summary>
    /// Генерирует код логического "или" с вычислением по короткой схеме.
    /// </summary>
    private void EmitLogicalOr(BinaryOperationExpression e)
    {
        Label trueLabel = _il.DefineLabel();
        Label endLabel = _il.DefineLabel();

        e.Left.Accept(this);
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Ceq);
        _il.Emit(OpCodes.Brfalse, trueLabel);

        e.Right.Accept(this);
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Ceq);
        _il.Emit(OpCodes.Brfalse, trueLabel);

        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Br, endLabel);

        _il.MarkLabel(trueLabel);
        _il.Emit(OpCodes.Ldc_I4_1);

        _il.MarkLabel(endLabel);
    }

    /// <summary>
    /// Генерирует код бинарной операции над строками.
    /// </summary>
    private void EmitStringsBinaryOperation(BinaryOperationExpression e)
    {
        switch (e.Operation)
        {
            case BinaryOperation.Add:
                e.Left.Accept(this);
                e.Right.Accept(this);

                MethodInfo concat = GetMethod(typeof(string), "Concat", [typeof(string), typeof(string)]);
                _il.Emit(OpCodes.Call, concat);
                break;

            case BinaryOperation.Equal:
            case BinaryOperation.NotEqual:
            case BinaryOperation.LessThan:
            case BinaryOperation.LessThanOrEqual:
            case BinaryOperation.GreaterThan:
            case BinaryOperation.GreaterThanOrEqual:
                e.Left.Accept(this);
                e.Right.Accept(this);

                MethodInfo compareOrdinal = GetMethod(typeof(string), "CompareOrdinal", [typeof(string), typeof(string)]);

                _il.Emit(OpCodes.Call, compareOrdinal);

                switch (e.Operation)
                {
                    case BinaryOperation.Equal:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Ceq);
                        break;

                    case BinaryOperation.NotEqual:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Ceq);
                        EmitLogicalNot();
                        break;

                    case BinaryOperation.LessThan:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Clt);
                        break;

                    case BinaryOperation.LessThanOrEqual:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Cgt);
                        EmitLogicalNot();
                        break;

                    case BinaryOperation.GreaterThan:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Cgt);
                        break;

                    case BinaryOperation.GreaterThanOrEqual:
                        _il.Emit(OpCodes.Ldc_I4_0);
                        _il.Emit(OpCodes.Clt);
                        EmitLogicalNot();
                        break;
                }

                break;

            default:
                throw new NotSupportedException($"Unknown binary operation for string: {e.Operation}.");
        }
    }

    /// <summary>
    /// Выполняет логическое отрицание результата.
    /// </summary>
    private void EmitLogicalNot()
    {
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Ceq);
    }

    /// <summary>
    /// Пишет вещественное число в консоль с правильным форматированием.
    /// </summary>
    private void WriteFloat()
    {
        LocalBuilder tempDouble = _il.DeclareLocal(typeof(double));

        _il.Emit(OpCodes.Stloc, tempDouble);

        _il.Emit(OpCodes.Ldloca, tempDouble);

        _il.Emit(OpCodes.Ldstr, "G15");

        MethodInfo invariantCultureGetter = typeof(CultureInfo)
            .GetProperty("InvariantCulture")!.GetMethod!;

        _il.Emit(OpCodes.Call, invariantCultureGetter);

        MethodInfo toStringMethod = typeof(double).GetMethod(
            "ToString",
            [typeof(string), typeof(IFormatProvider)])!;

        _il.Emit(OpCodes.Call, toStringMethod);

        MethodInfo writeMethod = GetMethod(typeof(Console), "Write", [typeof(string)]);
        _il.Emit(OpCodes.Call, writeMethod);
    }

    /// <summary>
    /// Находит статический метод указанного типа стандартной библиотеки классов .NET.
    /// </summary>
    private static MethodInfo GetMethod(Type type, string methodName, Type[] parameterTypes)
    {
        MethodInfo? method = type.GetMethod(methodName, parameterTypes);
        if (method == null)
        {
            string parameterTypeNames = string.Join(", ", parameterTypes.Select(t => t.Name));
            throw new InvalidOperationException($"Cannot find method {type.Name}.{methodName}({parameterTypeNames}.");
        }

        return method;
    }

    /// <summary>
    /// Добавляет новую область видимости переменных на стек.
    /// </summary>
    private void BeginScope()
    {
        _scopesStack.Push(new Dictionary<string, LocalBuilder>());
        _il.BeginScope();
    }

    /// <summary>
    /// Убирает текущую область видимости переменных со стека.
    /// </summary>
    private void EndScope()
    {
        _il.EndScope();
        _scopesStack.Pop();
    }

    /// <summary>
    /// Создает локальную переменную для i-го параметра функции (нумерация начинается с нуля).
    /// </summary>
    private void EmitDefineParameter(string name, TypeNode type, int argumentNo)
    {
        LocalBuilder local = _il.DeclareLocal(_typeMapper.MapTypeNode(type));

        _il.Emit(OpCodes.Ldarg, argumentNo);
        _il.Emit(OpCodes.Stloc, local);

        CurrentScope.Add(name, local);
    }

    private LocalBuilder FindVariable(string name)
    {
        foreach (Dictionary<string, LocalBuilder> scope in _scopesStack)
        {
            if (scope.TryGetValue(name, out LocalBuilder? local))
            {
                return local;
            }
        }

        throw new InvalidOperationException($"Variable '{name}' is not found in current scope");
    }

    private void EmitDeclareArrayVariable(string name, ArrayTypeNode arrayType, Expression? initialValue)
    {
        Type ilArrayType = _typeMapper.MapArrayType(arrayType.ElementType);
        Type ilElementType = _typeMapper.MapType(arrayType.ElementType);

        LocalBuilder arrayLocal = _il.DeclareLocal(ilArrayType);
        CurrentScope[name] = arrayLocal;

        if (initialValue is ArrayLiteralExpression literal)
        {
            literal.Accept(this);
            _il.Emit(OpCodes.Stloc, arrayLocal);
            return;
        }

        if (initialValue is VariableExpression sourceVariable)
        {
            sourceVariable.Accept(this);
            _il.Emit(OpCodes.Stloc, arrayLocal);
            return;
        }

        arrayType.Size.Accept(this);
        _il.Emit(OpCodes.Newarr, ilElementType);
        _il.Emit(OpCodes.Stloc, arrayLocal);

        if (initialValue == null)
        {
            EmitFillArrayWithDefault(arrayLocal, arrayType.Size, arrayType.ElementType);
        }
        else
        {
            throw new InvalidOperationException("Unsupported array initializer expression");
        }
    }

    private void EmitFillArrayWithDefault(LocalBuilder arrayLocal, Expression sizeExpression, ValueType elementType)
    {
        Type ilElementType = _typeMapper.MapType(elementType);
        LocalBuilder sizeLocal = SaveExpressionToLocal(sizeExpression, typeof(int));

        LocalBuilder indexLocal = _il.DeclareLocal(typeof(int));
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Stloc, indexLocal);

        Label loopStart = _il.DefineLabel();
        Label loopEnd = _il.DefineLabel();

        _il.MarkLabel(loopStart);
        _il.Emit(OpCodes.Ldloc, indexLocal);
        _il.Emit(OpCodes.Ldloc, sizeLocal);
        _il.Emit(OpCodes.Bge, loopEnd);

        _il.Emit(OpCodes.Ldloc, arrayLocal);
        _il.Emit(OpCodes.Ldloc, indexLocal);
        EmitDefaultScalarValue(elementType);
        _il.Emit(OpCodes.Stelem, ilElementType);

        _il.Emit(OpCodes.Ldloc, indexLocal);
        _il.Emit(OpCodes.Ldc_I4_1);
        _il.Emit(OpCodes.Add);
        _il.Emit(OpCodes.Stloc, indexLocal);
        _il.Emit(OpCodes.Br, loopStart);

        _il.MarkLabel(loopEnd);
    }

    private void EmitDefaultScalarValue(ValueType type)
    {
        switch (type)
        {
            case ValueType.Integer:
                _il.Emit(OpCodes.Ldc_I4_0);
                break;
            case ValueType.Float:
                _il.Emit(OpCodes.Ldc_R8, 0.0);
                break;
            case ValueType.String:
                _il.Emit(OpCodes.Ldstr, string.Empty);
                break;
            default:
                throw new NotSupportedException($"Default value for type {type} is not supported");
        }
    }

    private void EmitArrayElementLoad(ArrayAccessExpression access)
    {
        Type elementType = _typeMapper.MapType(access.ResultType);
        LocalBuilder arrayLocal = EmitArrayReferenceToLocal(access.Array);
        LocalBuilder indexLocal = SaveExpressionToLocal(access.Index, typeof(int));
        EmitArrayBoundsCheck(indexLocal, arrayLocal);
        _il.Emit(OpCodes.Ldloc, arrayLocal);
        _il.Emit(OpCodes.Ldloc, indexLocal);
        _il.Emit(OpCodes.Ldelem, elementType);
    }

    private void EmitArrayElementStore(ArrayAccessExpression access, Action emitValue)
    {
        Type elementType = _typeMapper.MapType(access.ResultType);
        LocalBuilder arrayLocal = EmitArrayReferenceToLocal(access.Array);
        LocalBuilder indexLocal = SaveExpressionToLocal(access.Index, typeof(int));
        EmitArrayBoundsCheck(indexLocal, arrayLocal);
        _il.Emit(OpCodes.Ldloc, arrayLocal);
        _il.Emit(OpCodes.Ldloc, indexLocal);
        emitValue();
        _il.Emit(OpCodes.Stelem, elementType);
    }

    private LocalBuilder EmitArrayReferenceToLocal(Expression arrayExpression)
    {
        if (arrayExpression is VariableExpression variable)
        {
            LocalBuilder existing = FindVariable(variable.Name);
            LocalBuilder copy = _il.DeclareLocal(existing.LocalType);
            _il.Emit(OpCodes.Ldloc, existing);
            _il.Emit(OpCodes.Stloc, copy);
            return copy;
        }

        throw new NotSupportedException(
            $"Array expression {arrayExpression.GetType().Name} is not supported"
        );
    }

    private void EmitArrayBoundsCheck(LocalBuilder indexLocal, LocalBuilder arrayLocal)
    {
        Label okLabel = _il.DefineLabel();
        Label throwLabel = _il.DefineLabel();
        ConstructorInfo exceptionConstructor = typeof(IndexOutOfRangeException).GetConstructor(Type.EmptyTypes)!;

        _il.Emit(OpCodes.Ldloc, indexLocal);
        _il.Emit(OpCodes.Ldc_I4_0);
        _il.Emit(OpCodes.Blt, throwLabel);

        _il.Emit(OpCodes.Ldloc, indexLocal);
        _il.Emit(OpCodes.Ldloc, arrayLocal);
        _il.Emit(OpCodes.Ldlen);
        _il.Emit(OpCodes.Conv_I4);
        _il.Emit(OpCodes.Bge, throwLabel);

        _il.Emit(OpCodes.Br, okLabel);

        _il.MarkLabel(throwLabel);
        _il.Emit(OpCodes.Newobj, exceptionConstructor);
        _il.Emit(OpCodes.Throw);

        _il.MarkLabel(okLabel);
    }

    private void EmitReadIntoLocal(LocalBuilder local)
    {
        MethodInfo readLineMethod = GetMethod(typeof(Console), "ReadLine", Type.EmptyTypes);
        _il.Emit(OpCodes.Call, readLineMethod);

        Type variableType = local.LocalType;
        if (variableType == typeof(string))
        {
        }
        else if (variableType == typeof(int))
        {
            MethodInfo parseIntMethod = GetMethod(typeof(int), "Parse", [typeof(string)]);
            _il.Emit(OpCodes.Call, parseIntMethod);
        }
        else if (variableType == typeof(double))
        {
            MethodInfo parseDoubleMethod = GetMethod(typeof(double), "Parse", [typeof(string)]);
            _il.Emit(OpCodes.Call, parseDoubleMethod);
        }
        else
        {
            throw new InvalidOperationException($"Input for type '{variableType}' is not supported");
        }

        _il.Emit(OpCodes.Stloc, local);
    }

    private void EmitReadScalar(ValueType type)
    {
        MethodInfo readLineMethod = GetMethod(typeof(Console), "ReadLine", Type.EmptyTypes);
        _il.Emit(OpCodes.Call, readLineMethod);

        switch (type)
        {
            case ValueType.Integer:
                MethodInfo parseIntMethod = GetMethod(typeof(int), "Parse", [typeof(string)]);
                _il.Emit(OpCodes.Call, parseIntMethod);
                break;
            case ValueType.Float:
                MethodInfo parseDoubleMethod = GetMethod(typeof(double), "Parse", [typeof(string)]);
                _il.Emit(OpCodes.Call, parseDoubleMethod);
                break;
            case ValueType.String:
                break;
            default:
                throw new InvalidOperationException($"Input for type '{type}' is not supported");
        }
    }

    private LocalBuilder SaveExpressionToLocal(Expression expression, Type localType)
    {
        expression.Accept(this);
        LocalBuilder local = _il.DeclareLocal(localType);
        _il.Emit(OpCodes.Stloc, local);
        return local;
    }

    /// <summary>
    /// Приводит два значения на стеке к общему типу перед сравнением.
    /// </summary>
    private void EmitConvertToCommonType(ValueType leftType, ValueType rightType)
    {
        if (leftType == ValueType.Float || rightType == ValueType.Float)
        {
            if (leftType == ValueType.Integer)
            {
                _il.Emit(OpCodes.Conv_R8);
            }

            if (rightType == ValueType.Integer)
            {
                _il.Emit(OpCodes.Conv_R8);
            }
        }
    }

    /// <summary>
    /// Декорирует имя функции, чтобы гарантировать отсутствие пересечений с системными именами методов
    ///  (такими как "Main").
    /// </summary>
    private string GetUserFunctionMethodName(string name)
    {
        return "Paspp" + name;
    }

    private MethodBuilder DefineProgramClassMethod(string name, Type returnType, Type[] parameterTypes)
    {
        return _programTypeBuilder.DefineMethod(
            name,
            MethodAttributes.Public | MethodAttributes.Static,
            returnType,
            parameterTypes
        );
    }
}