# Грамматика языка Pascal++

## Приоритет операторов

| Приоритет (по убыванию) | Операторы              | Ассоциативность |
|-------------------------|------------------------|-----------------|
| 10                      | ( ) (группировка)      | -               |
| 9                       | Вызов функции, . , [ ]  | Левая           |
| 8                       | Унарные +, -, !         | Правая          |
| 7                       | ^ (степень)             | Правая          |
| 6                       | *, /, %                 | Левая           |
| 5                       | бинарные + -            | Левая           |
| 4                       | ==, !=, <, >, <=, >=    | Левая           |
| 3                       | @ (логическое И)        | Левая           |
| 2                       | \|\| (логическое ИЛИ)   | Левая           |

## Встроенные функции

| Функция         | Описание                             |
|-----------------|--------------------------------------|
| abs_f(x)          | Возвращает модуль числа (float)              |
| min_f(x, y, ...)  | Возвращает наименьшее (float) из чисел (float)       |
| max_f(x, y, ...)  | Возвращает наибольшее (float) из чисел (float)      |
| round(x)        | Округляет(float) до ближайшего целого (integer)        |
| len(str)        | возвращает длину строки в числовом виде (integer) |
| getsymbol(str, 5) | возвращает подстроку под индексом 5(integer) в изначальной строке |
| tostring_i(integer)| преобразует integer в string |
| tostring_f(float) | преобразует float в string |

## Массивы

- Тип массива: `arr[n] of <базовый_тип>`, где базовый тип — `integer`, `string` или `float`.
- Доступ к элементу: выражение с индексацией `myArray[index]` (чтение и запись).

## Структуры

- Тип структуры задаётся перечислением полей: `struct { поле1 : тип1, поле2 : тип2, ... }`.
- Литерал структуры: инициализация всех полей в фигурных скобках: `{ поле1 : выражение1, поле2 : выражение2 }`.
- Доступ к полю на чтение и запись: `myObject.field` (значение)


# Грамматика языка в нотации EBNF

	```
		(* ==================== *)
		(* Лексика операторов, прочих литералов и правил идентификаторов описаны в спецификации 01_lexemes.md *)
		(* ==================== *)

        (* ==================== *)
		(* Грамматика литералов  *)
		(* ==================== *)

            literal = integer_literal | float_literal | string_literal | array_literal | struct_literal ;

            array_literal = "[", [ expression, { ",", expression } ], "]" ;

            struct_literal = "{", [ identifier, ":", expression, { ",", identifier, ":", expression } ], "}" ;

		(* ==================== *)
		(* Основные выражения   *)
		(* ==================== *)
			
			expression = logical_or_expression ;

			logical_or_expression = logical_and_expression, { logical_or_operator, logical_and_expression } ;

			logical_and_expression = comparison_expression, { logical_and_operator, comparison_expression } ;

			comparison_expression = additive_expression, [ comparison_operator, additive_expression ] ;

			additive_expression = term_expression, { additive_operator, term_expression } ;

			term_expression = exponentiation_expression, { multiplicative_operator, exponentiation_expression } ;

			exponentiation_expression = unary_expression, [ "^", exponentiation_expression ] ;

			unary_expression = [ unary_operator ], postfix_expression ;

			postfix_expression = primary_expression, { index_access | member_access_dot } ;

			index_access = "[", expression, "]" ;

			member_access_dot = ".", identifier ;

			primary_expression = literal | variable_access | function_call | array_literal | struct_literal | "(", expression, ")" ;

		(* ==================== *)
		(* Доступ к переменным  *)
		(* ==================== *)

			variable_access = identifier ;

		(* ==================== *)
		(* Функции и вызовы     *)
		(* ==================== *)

			function_call = function_name, "(", [ argument_list ], ")" ;

			function_name = builtin_function_name | identifier ;

			builtin_function_name = "abs" 
				  | "min" 
				  | "max" 
				  | "round" 
                  | "len" 
                  | "getsymbol"
                  | "tostring"

			argument_list = expression, { ",", expression } ;


        (* ====================     *)
        (*  Инициализация программы *)
        (* ====================     *)

            program = "begin", { statement }, "end" ;

        (* ==================== *)
        (* Инструкции          *)
        (* ==================== *)

            statement = variable_declaration
                      | type_declaration
                      | function_declaration    
                      | assignment_statement
                      | for_statement
                      | output_statement
                      | input_statement
                      | break_statement
                      | continue_statement
                      | return_statement
                      | if_statement
                      | while_statement
                      | expression_statement  
                      | block ;

            block = "begin", { statement }, "end" ;

        (* ==================== *)
        (* Объявления типов *)
        (* ==================== *)

            type_declaration = "type", type_identifier, "=", type, ";" ;       
            type_identifier = identifier ;

        (* ==================== *)
        (* Объявления переменных *)
        (* ==================== *)

            variable_declaration = "var", identifier, ":", type, [ "=", expression ], ";" ;

            expression_statement = expression, ";" ;

        (* ==================== *)
        (* Объявление функций *)
        (* ==================== *)

            function_declaration = "function", function_name, "(", [ parameter_list ], ")", [ ":", type ], block ;

            parameter_list = parameter, { ",", parameter } ;

            parameter = identifier, ":", type ;

            type = base_type | array_type | struct_type | type_identifier ;

            base_type = "integer" | "float" | "string"  ;

            array_type = "arr", "[", expression, "]", "of", base_type

            struct_type = "struct", "{", field_list, "}" ;

            field_list = field_decl, { ",", field_decl } ;

            field_decl = identifier, ":", type ;

        (* ==================== *)
        (* Операторы управления *)
        (* ==================== *)

            if_statement = "if", "(", expression, ")", "then", block, [ "else", block ] ;

            for_statement = "for", identifier, "from", expression, "to", expression, "do", block ;

            while_statement = "while", "(", expression, ")", "do", block;

        (* ==================== *)
        (* Ввод-вывод          *)
        (* ==================== *)

            output_statement = "write", "(", argument_list, ")", ";" ;

            input_statement = "read", "(", left_hand_side, ")", ";" ;

        (* ==================== *)
        (* Контроль потоков     *)
        (* ==================== *)

            break_statement = "break", ";" ;

            continue_statement = "continue", ";" ;

            return_statement = "return", expression ";" ;

        (* ==================== *)
        (* Присваивание         *)
        (* ==================== *)

            assignment_statement = left_hand_side, "=", expression, ";" ;

            left_hand_side = identifier, { index_access | member_access_dot } ;

        (* ==================== *)
        (* Описание литералов, идентификаторов и др. лексем см в 01_lexemes.md  *)
        (* ==================== *)
    ```
