begin 
    write(x); 
end
