using System.CommandLine;

namespace Compiler;

public static class RootCommandFactory
{
    public static RootCommand Create()
    {
        var source = new Argument<string>("input")
        {
            Description = "Path to Pascal++ program source file",
            Arity = ArgumentArity.ExactlyOne,
        };
        var target = new Argument<string>("output")
        {
            Description = "Output path for generated executable file .NET",
            Arity = ArgumentArity.ExactlyOne,
        };

        RootCommand command = new("Сompiling a Pascal++ program into an executable file .NET");
        command.Add(source);
        command.Add(target);
        command.SetAction(parseResult =>
        {
            var input = parseResult.GetRequiredValue(source);
            var output = parseResult.GetRequiredValue(target);
            new CompilerDriver().Compile(input, output);
            return 0;
        });
        return command;
    }
}
