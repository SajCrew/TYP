using CompilerLexer;

namespace CompilerParser;

public class TokenStream
{
    private readonly Lexer _lexer;
    private Token _current;

    public TokenStream(string text)
    {
        _lexer = new Lexer(new TextScanner(text));
        _current = _lexer.ParseToken();
    }

    public Token Peek() => _current;

    public void Advance()
    {
        _current = _lexer.ParseToken();
    }
}
