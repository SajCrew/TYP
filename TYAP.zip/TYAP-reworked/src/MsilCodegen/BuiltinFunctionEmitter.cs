using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;

namespace MsilCodegen;

public class BuiltinFunctionEmitter
{
    public void EmitCallBuiltinFunction(string name, ILGenerator il)
    {
        switch (name)
        {
            case "abs_f": EmitMathCall(il, "Abs", 1); break;
            case "min_f": EmitMathCall(il, "Min", 2); break;
            case "max_f": EmitMathCall(il, "Max", 2); break;
            case "round": EmitMathCall(il, "Round", 1); break;
            case "len": EmitLength(il); break;
            case "getsymbol": EmitGetSymbol(il); break;
            case "tostring_i": EmitToStringI(il); break;
            case "tostring_f": EmitToStringF(il); break;
            default: throw new InvalidOperationException($"Unexpected built-in function: {name}");
        }
    }

    private static void EmitMathCall(ILGenerator il, string method, int arity)
    {
        Type[] argumentTypes = Enumerable.Repeat(typeof(double), arity).ToArray();
        il.Emit(OpCodes.Call, GetMethod(typeof(Math), method, argumentTypes));
    }

    /// <summary>
    /// Генерирует вызов встроенной функции len.
    /// </summary>
    private void EmitLength(ILGenerator il)
    {
        EmitStringInfoConstruction(il);
        PropertyInfo prop = typeof(StringInfo).GetProperty("LengthInTextElements")!;
        MethodInfo getter = prop.GetGetMethod()!;
        il.Emit(OpCodes.Callvirt, getter);
    }

    /// <summary>
    /// Генерирует вызов встроенной функции getsymbol.
    /// </summary>
    private void EmitGetSymbol(ILGenerator il)
    {
        LocalBuilder indexLocal = il.DeclareLocal(typeof(int));
        il.Emit(OpCodes.Stloc, indexLocal);

        EmitStringInfoConstruction(il);
        il.Emit(OpCodes.Ldloc, indexLocal);
        il.Emit(OpCodes.Ldc_I4_1);
        MethodInfo method = typeof(StringInfo).GetMethod("SubstringByTextElements", [typeof(int), typeof(int)])!;
        il.Emit(OpCodes.Callvirt, method);
    }

    private static void EmitStringInfoConstruction(ILGenerator il)
    {
        ConstructorInfo constructor = typeof(StringInfo).GetConstructor([typeof(string)])!;
        il.Emit(OpCodes.Newobj, constructor);
    }

    /// <summary>
    /// Генерирует вызов встроенной функции tostring для int.
    /// </summary>
    private void EmitToStringI(ILGenerator il)
    {
        LocalBuilder tempInt = il.DeclareLocal(typeof(int));
        il.Emit(OpCodes.Stloc, tempInt);
        il.Emit(OpCodes.Ldloca, tempInt);
        MethodInfo toStringMethod = typeof(int).GetMethod("ToString", Type.EmptyTypes)!;
        il.Emit(OpCodes.Call, toStringMethod);
    }

    private void EmitToStringF(ILGenerator il)
    {
        LocalBuilder tempDouble = il.DeclareLocal(typeof(double));
        il.Emit(OpCodes.Stloc, tempDouble);
        il.Emit(OpCodes.Ldloca, tempDouble);
        il.Emit(OpCodes.Ldstr, "G15");
        MethodInfo invariantCultureGetter = typeof(CultureInfo)
            .GetProperty("InvariantCulture")!.GetMethod!;
        il.Emit(OpCodes.Call, invariantCultureGetter);
        MethodInfo toStringMethod = typeof(double).GetMethod(
            "ToString",
            [typeof(string), typeof(IFormatProvider)])!;
        il.Emit(OpCodes.Call, toStringMethod);
    }

    /// <summary>
    /// Находит статический метод.
    /// </summary>
    private static MethodInfo GetMethod(Type type, string methodName, Type[] parameterTypes)
    {
        MethodInfo? method = type.GetMethod(methodName, parameterTypes);
        if (method == null)
        {
            string parameterTypeNames = string.Join(", ", parameterTypes.Select(t => t.Name));
            throw new InvalidOperationException($"Cannot find method {type.Name}.{methodName}({parameterTypeNames}).");
        }

        return method;
    }
}