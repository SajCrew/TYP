using System.Text;

namespace CompilerLexer;

public class Lexer
{
    private readonly IScanner _scanner;

    private static readonly IReadOnlyDictionary<string, TokenType> Keywords =
        new Dictionary<string, TokenType>()
    {
        { "begin", TokenType.Begin },
        { "end", TokenType.End },
        { "var", TokenType.Var },
        { "integer", TokenType.IntegerType },
        { "float", TokenType.FloatType },
        { "string", TokenType.StringType },
        { "if", TokenType.If },
        { "then", TokenType.Then },
        { "else", TokenType.Else },
        { "for", TokenType.For },
        { "from", TokenType.From },
        { "to", TokenType.To },
        { "do", TokenType.Do },
        { "while", TokenType.While },
        { "write", TokenType.Output },
        { "read", TokenType.Input },
        { "break", TokenType.Break },
        { "continue", TokenType.Continue },
        { "return", TokenType.Return },
        { "function", TokenType.Function },
        { "arr", TokenType.Array },
        { "of", TokenType.Of },
        { "struct", TokenType.Structure },
    };

    public Lexer(IScanner scanner)
    {
        _scanner = scanner;
    }

    public Token ParseToken()
    {
        SkipWhiteSpacesAndComments();

        if (_scanner.IsEnd())
        {
            return new Token(TokenType.EndOfFile);
        }

        char currentChar = _scanner.Peek();

        if (char.IsAsciiLetter(currentChar) || currentChar == '_')
        {
            return ParseIdentifierOrKeyword();
        }

        if (char.IsAsciiDigit(currentChar))
        {
            return ParseNumericLiteral();
        }

        if (currentChar == '"')
        {
            return ParseStringLiteral();
        }

        return ParseOperatorOrDelimiter();
    }

    // Punctuation and one-character operators share a single lookup table.
    private static readonly IReadOnlyDictionary<char, TokenType> SingleCharacterTokens =
        new Dictionary<char, TokenType>
        {
            ['{'] = TokenType.LBrace,
            ['}'] = TokenType.RBrace,
            ['('] = TokenType.LParen,
            [')'] = TokenType.RParen,
            ['['] = TokenType.LBracket,
            [']'] = TokenType.RBracket,
            [';'] = TokenType.Semicolon,
            [','] = TokenType.Comma,
            [':'] = TokenType.Colon,
            ['+'] = TokenType.PlusSign,
            ['-'] = TokenType.MinusSign,
            ['*'] = TokenType.MultiplySign,
            ['/'] = TokenType.DivideSign,
            ['%'] = TokenType.ModuloSign,
            ['^'] = TokenType.ExponentiationSign,
            ['@'] = TokenType.LogicalAnd,
            ['.'] = TokenType.Dot,
        };

    private Token ParseOperatorOrDelimiter()
    {
        char symbol = _scanner.Peek();
        if (SingleCharacterTokens.TryGetValue(symbol, out TokenType kind))
        {
            _scanner.Advance();
            return new Token(kind);
        }

        return symbol switch
        {
            '=' => ParseAssignOrEqualsOperator(),
            '!' => ParseNotEqualOrLogicalNotOperator(),
            '<' => ParseLessThanOperator(),
            '>' => ParseGreaterThanOperator(),
            '|' => ParseOrOperator(),
            _ => ConsumeInvalidSymbol(symbol),
        };
    }

    private Token ConsumeInvalidSymbol(char symbol)
    {
        _scanner.Advance();
        return new Token(TokenType.Error, new TokenValue(symbol.ToString()));
    }

    private Token ParseAssignOrEqualsOperator()
    {
        _scanner.Advance();

        if (_scanner.Peek() == '=')
        {
            _scanner.Advance();
            return new Token(TokenType.Equal);
        }

        return new Token(TokenType.Assign);
    }

    private Token ParseNotEqualOrLogicalNotOperator()
    {
        _scanner.Advance();

        if (_scanner.Peek() == '=')
        {
            _scanner.Advance();
            return new Token(TokenType.NotEqual);
        }

        return new Token(TokenType.LogicalNot);
    }

    private Token ParseLessThanOperator()
    {
        _scanner.Advance();

        if (_scanner.Peek() == '=')
        {
            _scanner.Advance();
            return new Token(TokenType.LessThanOrEqual);
        }

        return new Token(TokenType.LessThan);
    }

    private Token ParseGreaterThanOperator()
    {
        _scanner.Advance();

        if (_scanner.Peek() == '=')
        {
            _scanner.Advance();
            return new Token(TokenType.GreaterThanOrEqual);
        }

        return new Token(TokenType.GreaterThan);
    }

    private Token ParseOrOperator()
    {
        _scanner.Advance();
        if (_scanner.Peek() == '|')
        {
            _scanner.Advance();
            return new Token(TokenType.LogicalOr);
        }

        return new Token(TokenType.Error, new TokenValue("|"));
    }

    private Token ParseIdentifierOrKeyword()
    {
        StringBuilder name = new();
        bool invalid = false;
        while (true)
        {
            char current = _scanner.Peek();
            if (!char.IsLetterOrDigit(current) && current != '_')
            {
                break;
            }

            invalid |= !char.IsAsciiLetterOrDigit(current) && current != '_';
            name.Append(current);
            _scanner.Advance();
        }

        string identifier = name.ToString();
        if (invalid)
        {
            return new Token(TokenType.Error, new TokenValue(identifier));
        }

        return Keywords.TryGetValue(identifier, out TokenType keyword)
            ? new Token(keyword)
            : new Token(TokenType.Identifier, new TokenValue(identifier));
    }

    private Token ParseNumericLiteral()
    {
        int value = GetDigitValue(_scanner.Peek());
        _scanner.Advance();

        while (char.IsAsciiDigit(_scanner.Peek()))
        {
            value = value * 10 + GetDigitValue(_scanner.Peek());
            _scanner.Advance();
        }

        if (_scanner.Peek() == '.')
        {
            _scanner.Advance();
            return ParseFloatLiteral(value);
        }

        return new Token(TokenType.Integer, new TokenValue(value));
    }

    private Token ParseFloatLiteral(double integerPart)
    {
        double value = integerPart;
        double factor = 0.1d;

        while (char.IsAsciiDigit(_scanner.Peek()))
        {
            value += factor * GetDigitValue(_scanner.Peek());
            factor *= 0.1d;
            _scanner.Advance();
        }

        return new Token(TokenType.Float, new TokenValue(value));
    }

    private static int GetDigitValue(char c) => c - '0';

    private Token ParseStringLiteral()
    {
        _scanner.Advance(); // opening quotation mark
        StringBuilder content = new();

        while (!_scanner.IsEnd() && _scanner.Peek() != '"')
        {
            if (TryParseEscapeSequence(out char character))
            {
                content.Append(character);
                continue;
            }

            content.Append(_scanner.Peek());
            _scanner.Advance();
        }

        bool terminated = _scanner.Peek() == '"';
        if (terminated)
        {
            _scanner.Advance();
        }

        return new Token(
            terminated ? TokenType.StringLiteral : TokenType.Error,
            new TokenValue(content.ToString()));
    }

    private bool TryParseEscapeSequence(out char unescaped)
    {
        if (_scanner.Peek() != '\\')
        {
            unescaped = '\0';
            return false;
        }

        _scanner.Advance();

        unescaped = _scanner.Peek() switch
        {
            '\\' => '\\',
            'n' => '\n',
            't' => '\t',
            'r' => '\r',
            '\"' => '\"',
            _ => '\0',
        };

        if (unescaped != '\0')
        {
            _scanner.Advance();
            return true;
        }

        return false;
    }

    private void SkipWhiteSpacesAndComments()
    {
        bool skipped;
        do
        {
            SkipWhiteSpaces();
            skipped = TryParseMultilineComment() || TryParseSingleLineComment();
        }
        while (skipped);
    }

    private void SkipWhiteSpaces()
    {
        while (char.IsWhiteSpace(_scanner.Peek()))
        {
            _scanner.Advance();
        }
    }

    private bool TryParseMultilineComment()
    {
        if (_scanner.Peek() != '/' || _scanner.Peek(1) != '#')
        {
            return false;
        }

        while (!_scanner.IsEnd() && !(_scanner.Peek() == '#' && _scanner.Peek(1) == '/'))
        {
            _scanner.Advance();
        }

        if (_scanner.Peek() == '#' && _scanner.Peek(1) == '/')
        {
            _scanner.Advance();
            _scanner.Advance();
        }

        return true;
    }

    private bool TryParseSingleLineComment()
    {
        if (_scanner.Peek() != '#' || _scanner.Peek(1) != '#')
        {
            return false;
        }

        while (!_scanner.IsEnd() && _scanner.Peek() != '\n' && _scanner.Peek() != '\r')
        {
            _scanner.Advance();
        }

        return true;
    }
}