using System.Runtime.CompilerServices;
using System.Text;

namespace TestLibrary;

public static class Samples
{
    private const string DataDirectory = "data";

    public static string GetSampleProgram(string filename)
    {
        string filepath = Path.Join(
            GetClassDirectory(),
            DataDirectory,
            filename.Replace('/', Path.DirectorySeparatorChar)
        );
        return File.ReadAllText(filepath, Encoding.UTF8);
    }

    public static string GetSampleProgramPath(string filename)
    {
        return Path.Join(
            GetClassDirectory(),
            DataDirectory,
            filename.Replace('/', Path.DirectorySeparatorChar)
        );
    }

    private static string GetClassDirectory([CallerFilePath] string path = "")
    {
        return Path.GetDirectoryName(path) ?? throw new ArgumentException($"Could not get directory path from {path}");
    }
}